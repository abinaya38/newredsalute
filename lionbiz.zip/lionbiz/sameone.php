<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
    <!-- Basic Page Needs -->
    <meta charset="utf-8">
    <title>LionBiz</title>
    <meta name="author" content="Customer support and call center,
	Bookkeeping and accounting, Virtual assistant services, Social media marketing services, Software development service, Graphic and web design services in LionBiz ">
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- Bootstrap  -->
    <link rel="stylesheet" type="text/css" href="stylesheets/bootstrap.css" >
    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/style.css">
    <!-- Responsive -->
    <link rel="stylesheet" type="text/css" href="stylesheets/responsive.css">
    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="stylesheets/colors/color1.css" id="colors">
    <!-- Animation Style -->
    <link rel="stylesheet" type="text/css" href="stylesheets/animate.css">
    <!-- REVOLUTION LAYERS STYLES -->
    <link rel="stylesheet" type="text/css" href="assets/js/plugins/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="assets/js/plugins/revolution/css/layers.css">
    <link href="stylesheets/navigation.css" rel="stylesheet" type="text/css">
	<!-- THEME CSS -->
    <!-- Favicon and touch icons  -->
    <link href="images/favicon.png" type="image/png" rel="icon" sizes="48x48">
</head>    
<style>
/* 	.nav-flat-wrap {
	float: right;
    width: 70.2%;
	    margin-left: 20px;
   position: absolute;
     margin-left: 26%; 
	    margin-top: -50px;
} */

   
</style>
<body class="header_sticky page-loading"> 
    <!-- Preloader -->
    <section class="loading-overlay">
        <div class="preload-inner">
            <div class="wBall" id="wBall_1">
                <div class="wInnerBall"></div>
            </div>
            <div class="wBall" id="wBall_2">
                <div class="wInnerBall"></div>
            </div>
            <div class="wBall" id="wBall_3">
                <div class="wInnerBall"></div>
            </div>
            <div class="wBall" id="wBall_4">
                <div class="wInnerBall"></div>
            </div>
            <div class="wBall" id="wBall_5">
                <div class="wInnerBall"></div>
            </div>
        </div>
    </section>     
    <!-- Boxed -->
    <div class="boxed">
 <div class="site-header">
            <header id="header" class="header shawdow-header header-classic clearfix">
     <?php include_once('header.php'); ?>
</header>
</div>

			<?php  include_once('clock.php'); ?>
						
		
    <section class="flat-row section_carousel_metro2 ">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="title-section section-blog-title">
                            <h1 class="title fontsize36 fontweight600" style="text-align:center">We work from India for Middle East</h1>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
					<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title" >
							  Customer support and call center</h3>
							 
						</div>
						<div class="panel-body two-col">
						  <p>Are you looking for a company that can treat your customers better than you do? We can do this and more.
							Our in house psychologist constantly 	<a href="customersupport.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
						</div>
						
					</div>
				</div>
		         <div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">
							  Bookkeeping and accounting  </h3>
						</div>
						<div class="panel-body two-col">
						   <p>Do you spend a lot of time in your bookkeeping and accounting tasks? Would you rather have someone take the burden from you? 
										<a href="bookeeping.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
						</div>
						
					</div>
				</div>	
				 
				 <div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">
							  Virtual assistant services</h3>
						</div>
						<div class="panel-body two-col">
						<p>Do you have too much to do and not enough time to complete your work?Is it becoming increasingly difficult allocate time to focus 
								<a href="virtual.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
						</div>
						
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">
							  Social media marketing services</h3>
						</div>
						<div class="panel-body two-col">
						 <p>Would you like help marketing your business in social media? We can help you.
Over 1 billion people are using social media websites 
								<a href="socialmedia.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
</p> 
						</div>
						
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">
							  Software development service</h3>
						</div>
						<div class="panel-body two-col">
						  <p>Our software development services span across web software, cloud software, desktop software and mobile apps software applications. 
								<a href="softwaredevelopment.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
						</div>
						
					</div>
				</div>
				<div class="col-md-4">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h3 class="panel-title">
							 Graphic and web design services</h3>
						</div>
						<div class="panel-body two-col">
						  <p>We take great care and pride in creating designs that our customers are proud to show off. We can create any form of design for you on a budget 
								<a href="graphicdesign.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
						</div>
						
					</div>
				</div>

							
							<!--<div class="col-md-6">
                      <div class="box-content">
                                <h4 class="box-title"><a href="seo.php">Search Engine Optimization</a></h4>    
                                <p>Do you think that having a professional Website will bring in sales? This is a popular misconception. 
								<a href="seo.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
</p> 
                            </div>
                            </div>
							
							<div class="col-md-6">
                      <div class="box-content">
                                <h4 class="box-title"><a href="dataentry.php">Data entry services</a></h4>    
                                <p>We are your one stop solution for high quality, time bound and cost effective data entry and data processing services. 
								<a href="dataentry.php" style="color: #8b888e;    font-weight: 700;">Read more</a>
</p> 
                            </div>
                            </div>-->
							
                    </div>
                </div>
            </div>
        </section> 
     
		<?php include_once('footer.php'); ?>
        <!-- Go Top -->
        <a class="go-top">
            <i class="ti-angle-up"></i>
        </a> 
    </div>
    <!-- Javascript -->
    <script type="text/javascript" src="javascript/jquery.min.js"></script>
    <script type="text/javascript" src="javascript/bootstrap.min.js"></script> 
    <script type="text/javascript" src="javascript/jquery.easing.js"></script>  
    <script type="text/javascript" src="javascript/jquery-waypoints.js"></script> 
    <script type="text/javascript" src="javascript/imagesloaded.min.js"></script>
    <script type="text/javascript" src="javascript/owl.carousel.js"></script>
    <script type="text/javascript" src="javascript/jquery-countTo.js"></script>
    <script type="text/javascript" src="javascript/jquery.cookie.js"></script>
    <script type="text/javascript" src="javascript/jquery.tweet.min.js"></script>
    <script type="text/javascript" src="javascript/parallax.js"></script>
    <script type="text/javascript" src="javascript/jquery.magnific-popup.min.js"></script>
    <script type="text/javascript" src="javascript/switcher.js"></script>  
    <script type="text/javascript" src="javascript/main.js"></script>
    <!-- Revolution Slider -->
	<script src="javascript/redsalute.js"></script>
</body>
</html>