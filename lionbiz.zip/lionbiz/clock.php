<section class="flat-row home-business-s5">
					<div class="container">
					<div class="row">
					<div class="col-md-12">
					<div class="col-md-2"></div>
					<div class="col-md-2" style="text-align:center;">
						<iframe src="http://free.timeanddate.com/clock/i68s7l3o/n169/szw160/szh160/hocfff/hbw0/cf100/hgr0/fas20/facfff/fdi86/mqc000/mqs2/mql3/mqw4/mqd70/mhc000/mhs2/mhl3/mhw4/mhd70/mmv0/hwm1/hhs3/hms3/hsc00f" frameborder="0" width="160" height="160"></iframe>



<p style="font-weight: 700;">OMAN</p>							</div>
						<div class="col-md-2" style="text-align:center;">
						<iframe src="http://free.timeanddate.com/clock/i68s7l3o/n8/szw160/szh160/hocfff/hbw0/cf100/hgr0/fas20/facfff/fdi86/mqc000/mqs2/mql3/mqw4/mqd70/mhc000/mhs2/mhl3/mhw4/mhd70/mmv0/hwm1/hhs3/hms3/hsc00f" frameborder="0" width="160" height="160"></iframe>

<p style="font-weight: 700;">QATAR</p>							</div>

						
						<div class="col-md-2" style="text-align:center;">
					<iframe src="http://free.timeanddate.com/clock/i68s7l3o/n776/szw160/szh160/hocfff/hbw0/cf100/hgr0/fas20/facfff/fdi86/mqc000/mqs2/mql3/mqw4/mqd70/mhc000/mhs2/mhl3/mhw4/mhd70/mmv0/hwm1/hhs3/hms3/hsc00f" frameborder="0" width="160" height="160"></iframe>

<p style="font-weight: 700;">UAE</p>							</div>

						<div class="col-md-2" style="text-align:center;">
						<iframe src="http://free.timeanddate.com/clock/i68s7l3o/n176/szw160/szh160/hocfff/hbw0/cf100/hgr0/fas20/facfff/fdi86/mqc000/mqs2/mql3/mqw4/mqd70/mhc000/mhs2/mhl3/mhw4/mhd70/mmv0/hwm1/hhs3/hms3/hsc00f" frameborder="0" width="160" height="160"></iframe>


						<p style="font-weight: 700;">INDIA</p>							</div>
					<div class="col-md-2"></div>

						</div>
						</div>
						</div>
						
			</section>